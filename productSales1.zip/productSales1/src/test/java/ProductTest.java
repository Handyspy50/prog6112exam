/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.productsales1.Product;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @author nkosi
 */
public class ProductTest {

    @Test
    public void GetTotalProductsSales_WithValidData_ReturnsCorrectValue() {

        Product product = new Product();

        assertEquals(240, product.GetTotalProductsSold());
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {

        Product product = new Product();

        assertEquals(80.0, product.GetAverageProductSold());
    }
}

